"""Semantic FAQ cache."""
